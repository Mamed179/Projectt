package com.example.ggg

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.transition.Visibility
import com.example.ggg.databinding.ActivityGuitarBinding
import com.example.ggg.databinding.ActivityMainBinding

class Guitar : AppCompatActivity() {
    lateinit var bindingClass: ActivityGuitarBinding
    private val todos = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindingClass = ActivityGuitarBinding.inflate(layoutInflater)
        setContentView(bindingClass.root)
        val colors = listOf(
            ContextCompat.getColor(this, R.color.item_color_1),
            ContextCompat.getColor(this, R.color.item_color_2),
            ContextCompat.getColor(this, R.color.item_color_3),
            ContextCompat.getColor(this, R.color.item_color_4)
        )


        // Инициализация адаптера с кастомным layout
        adapter = object : ArrayAdapter<String>(
            this,
            R.layout.list_work_item,
            R.id.taskText,
            todos
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                view.setBackgroundColor(colors[position % colors.size])
                val deleteBtn = view.findViewById<ImageButton>(R.id.deleteButton)

                deleteBtn.setOnClickListener {
                    AlertDialog.Builder(this@Guitar)
                        .setTitle("Удаление")
                        .setMessage("Удалить '${todos[position]}'?")
                        .setNegativeButton("Да") { _, _ ->
                            // Запускаем анимацию перед удалением
                            val anim =
                                AnimationUtils.loadAnimation(this@Guitar, R.anim.slide_out).apply {
                                    setAnimationListener(object : Animation.AnimationListener {
                                        override fun onAnimationStart(animation: Animation?) {}

                                        override fun onAnimationEnd(animation: Animation?) {
                                            // Удаляем после завершения анимации
                                            todos.removeAt(position)
                                            notifyDataSetChanged()
                                            Toast.makeText(
                                                this@Guitar,
                                                "Удалено",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }

                                        override fun onAnimationRepeat(animation: Animation?) {}
                                    })
                                }
                            view.startAnimation(anim)
                        }
                        .setPositiveButton("Нет", null)
                        .show()
                }

                return view
            }
        }

        bindingClass.listWork.adapter = adapter

        // Добавление элемента
        bindingClass.buttonWorkAdd.setOnClickListener {
            val text = bindingClass.workPole.text.toString().trim()
            if(text.isNotEmpty()) {
                adapter.insert(text, 0)
                bindingClass.workPole.text.clear()
            } else {
                Toast.makeText(this, "Введите текст!", Toast.LENGTH_SHORT).show()
            }
        }

        bindingClass.readyButton.setOnClickListener {
            if(bindingClass.goalGuitarOne.currentTextColor == Color.WHITE){
                bindingClass.readyButton.setImageResource(R.drawable.return_back)
                bindingClass.goalGuitarOne.setTextColor(Color.GREEN)
                bindingClass.readyText.visibility = View.VISIBLE
            }
            else if (bindingClass.goalGuitarOne.currentTextColor == Color.GREEN)
                {
                bindingClass.readyButton.setImageResource(R.drawable.circle)
                bindingClass.goalGuitarOne.setTextColor(Color.WHITE)
                    bindingClass.readyText.visibility = View.INVISIBLE
            }
        }
    }
}