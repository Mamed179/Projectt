package com.example.ggg

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Menu_hobby : AppCompatActivity() {

    private lateinit var recycleView: RecyclerView
    private lateinit var dataList: ArrayList<DataClass>
    lateinit var imageList: Array<Int>
    lateinit var titleList: Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_hobby)

        imageList = arrayOf(
            R.drawable.guitar2,
            R.drawable.draw,
            R.drawable.book,
            R.drawable.dont_kyrit,
            R.drawable.sport,
            R.drawable.everyday,
            R.drawable.collection,
            R.drawable.cook)

        titleList = arrayOf(
            "Играть на гитаре",
            "Рисование",
            "Читать книги",
            "Бросить курить",
            "Заняться спортом",
            "Ежедневная",
            "Коллекционирование",
            "Кулинария")

        recycleView = findViewById(R.id.hobbilist)
        recycleView.layoutManager = LinearLayoutManager(this)
        recycleView.setHasFixedSize(true)
        dataList = arrayListOf<DataClass>()
        getData()
    }


    private fun getData(){
        for (i in imageList.indices){
            val dataClass = DataClass(imageList[i], titleList[i])
            dataList.add(dataClass)
        }

        var adapter = AdapterClass(dataList)
        recycleView.adapter = adapter
        adapter.setOnItemClickListener(object : AdapterClass.onItemClickListener{
            override fun onItemClick(position: Int) {
                if (position == 0){
                    val intent = Intent(this@Menu_hobby, Guitar::class.java)
                    startActivity(intent)
                }
            }

        })
    }
}