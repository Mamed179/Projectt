package com.example.ggg

data class DataClass(var dataImage: Int, var dataTitle: String)
