package com.example.pp3

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.pp3.databinding.ActivityOldpriv1Binding
import com.example.pp3.databinding.ActivityOldpriv6Binding

class Oldpriv6 : AppCompatActivity() {
    lateinit var bindingClasss: ActivityOldpriv6Binding
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        bindingClasss = ActivityOldpriv6Binding.inflate(layoutInflater)
        setContentView(bindingClasss.root)
        bindingClasss.bb5.setOnClickListener {
            var intent= Intent(this,Menuhobb::class.java)
            startActivity(intent)
        }
    }
}