package com.example.pp3

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.pp3.databinding.ActivityOldpriv1Binding
import com.example.pp3.databinding.ActivityOldpriv2Binding

class Oldpriv2 : AppCompatActivity() {
    lateinit var bindingClasss: ActivityOldpriv2Binding
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        bindingClasss = ActivityOldpriv2Binding.inflate(layoutInflater)
        setContentView(bindingClasss.root)
        bindingClasss.bb1.setOnClickListener {
            var intent= Intent(this,Menuhobb::class.java)
            startActivity(intent)
        }
    }
}