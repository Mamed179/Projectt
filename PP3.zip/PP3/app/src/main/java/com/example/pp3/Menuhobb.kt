package com.example.pp3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.pp3.databinding.ActivityMainBinding
import com.example.pp3.databinding.ActivityMenuhobbBinding

class Menuhobb : AppCompatActivity() {
    lateinit var bindingClasss: ActivityMenuhobbBinding

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        bindingClasss = ActivityMenuhobbBinding.inflate(layoutInflater)
        setContentView(bindingClasss.root)
        bindingClasss.buttonMain2.setOnClickListener {
            var intent=Intent(this,Newpriv1::class.java)
            startActivity(intent)
        }
        bindingClasss.b2.setOnClickListener {
            var intentt=Intent(this,Oldpriv1::class.java)
            startActivity(intentt)
        }
        bindingClasss.b3.setOnClickListener {
            var intenttt=Intent(this,Oldpriv2::class.java)
            startActivity(intenttt)
        }
        bindingClasss.b4.setOnClickListener {
            var intentttt=Intent(this,Oldpriv3::class.java)
            startActivity(intentttt)
        }
        bindingClasss.b5.setOnClickListener {
            var intenttttt=Intent(this,Oldpriv4::class.java)
            startActivity(intenttttt)
        }
        bindingClasss.b6.setOnClickListener {
            var intentttttt=Intent(this,Oldpriv5::class.java)
            startActivity(intentttttt)
        }
        bindingClasss.b7.setOnClickListener {
            var intenttttttt=Intent(this,Oldpriv6::class.java)
            startActivity(intenttttttt)
        }
        bindingClasss.b8.setOnClickListener {
            var intentttttttt=Intent(this,Oldpriv7::class.java)
            startActivity(intentttttttt)
        }
        bindingClasss.b9.setOnClickListener {
            var intenttttttttt=Intent(this,Oldpriv8::class.java)
            startActivity(intenttttttttt)
        }
    }
}