package com.example.pp3

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.pp3.databinding.ActivityOldpriv1Binding
import com.example.pp3.databinding.ActivityOldpriv5Binding

class Oldpriv5 : AppCompatActivity() {
    lateinit var bindingClasss: ActivityOldpriv5Binding
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        bindingClasss = ActivityOldpriv5Binding.inflate(layoutInflater)
        setContentView(bindingClasss.root)
        bindingClasss.bb4.setOnClickListener {
            var intent= Intent(this,Menuhobb::class.java)
            startActivity(intent)
        }
    }
}