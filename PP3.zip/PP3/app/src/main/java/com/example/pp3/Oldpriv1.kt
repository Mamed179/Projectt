package com.example.pp3

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.pp3.databinding.ActivityMenuhobbBinding
import com.example.pp3.databinding.ActivityOldpriv1Binding

class Oldpriv1 : AppCompatActivity() {
    lateinit var bindingClasss: ActivityOldpriv1Binding
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        bindingClasss = ActivityOldpriv1Binding.inflate(layoutInflater)
        setContentView(bindingClasss.root)
        bindingClasss.bb.setOnClickListener {
            var intent= Intent(this,Menuhobb::class.java)
            startActivity(intent)
        }
    }
}