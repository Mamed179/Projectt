package com.example.pp3

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.pp3.databinding.ActivityOldpriv1Binding
import com.example.pp3.databinding.ActivityOldpriv4Binding

class Oldpriv4 : AppCompatActivity() {
    lateinit var bindingClasss: ActivityOldpriv4Binding
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        bindingClasss = ActivityOldpriv4Binding.inflate(layoutInflater)
        setContentView(bindingClasss.root)
        bindingClasss.bb3.setOnClickListener {
            var intent= Intent(this,Menuhobb::class.java)
            startActivity(intent)
        }
    }
}